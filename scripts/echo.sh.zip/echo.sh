#!/bin/bash

echo "tracker: $1 "
echo "name/id: $2 "
echo "hash: $3 "
echo "message: $4 "
echo "date_str: $5 "
echo "Количество аргументов: $#"
